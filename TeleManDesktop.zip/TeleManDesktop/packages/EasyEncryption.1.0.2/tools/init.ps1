param($installPath, $toolsPath, $package)
$DTE.ItemOperations.Navigate("https://github.com/polischuk/EasyEncryption/wiki/Usage-wiki")